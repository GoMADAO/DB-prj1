CREATE TABLE STAFF(
	staff_id		INTEGER,
	name			VARCHAR2(40)	NOT NULL,
	office_hour		VARCHAR2(40)	NOT NULL,
	office_location	VARCHAR2(100)	NOT NULL,
	PRIMARY KEY (staff_id)
);
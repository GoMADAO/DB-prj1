CREATE TABLE DICT(
	dic_id		INTEGER,
	type		VARCHAR2(20),
	value		VARCHAR2(20),
	key			INTEGER,
	PRIMARY KEY (dic_id)
);